const breath = 'locked';
const scream = 'fed';